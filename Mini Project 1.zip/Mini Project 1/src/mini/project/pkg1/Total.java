package mini.project.pkg1;

/**
 * @author Joseph Muchengeti && Joseph-Ben Okanlawon
 */
public class Total {

    private double total;

    public Total() {

    }

    public Total(double total) {

        this.total = total;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

}
