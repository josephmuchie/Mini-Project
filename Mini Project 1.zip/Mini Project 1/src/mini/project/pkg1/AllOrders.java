package mini.project.pkg1;

/**
 * @author Joseph Muchengeti && Joseph-Ben Okanlawon
 */
import java.util.*;

public class AllOrders {

    private ArrayList allOrders = new ArrayList();

    public AllOrders() {
    }

    public ArrayList getAllOrders() {
        return allOrders;
    }

    public void setAllOrders(ArrayList orders) {
        this.allOrders = orders;
    }

}
